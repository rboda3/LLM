import requests
from bs4 import BeautifulSoup
import json
import yaml
import os
import chardet
import string
from prompts import generate_searches_prompt, get_search_page_prompt
from termcolor import colored
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

def load_config(file_path):
    with open(file_path, 'r') as file:
        config = yaml.safe_load(file)
        for key, value in config.items():
            os.environ[key] = value

class WebSearcher:
    def __init__(self, model, verbose=False, model_endpoint=None, server=None, stop=None):
        self.server = server
        self.model_endpoint = model_endpoint
        load_config('config.yaml')
        self.api_key = os.getenv("OPENAI_API_KEY") if server == 'openai' else None
        self.headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}' if self.api_key else ''
        }
        self.model = model
        self.verbose = verbose
        self.stop = stop
        self.session = requests.Session()
        retries = Retry(total=5, backoff_factor=1, status_forcelist=[502, 503, 504])
        self.session.mount('https://', HTTPAdapter(max_retries=retries))

    def generate_searches(self, plan, query):
        payload = {
            "model": self.model,
            "prompt": f"Query: {query}\n\nPlan: {plan}",
            "format": "json",
            "system": generate_searches_prompt,
            "stream": False,
            "temperature": 0
        } if self.server == 'ollama' else {
            "model": self.model,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": generate_searches_prompt},
                {"role": "user", "content": f"Query: {query}\n\nPlan: {plan}"}
            ],
            "temperature": 0,
            "stop": self.stop
        }
        if self.server == 'openai':
            del payload["stop"]
        
        try: 
            response = self.session.post(self.model_endpoint, headers=self.headers, json=payload)
            response.raise_for_status()
            response_dict = response.json()
            search_query = json.loads(response_dict['response'])['response'] if self.server == 'ollama' else json.loads(response_dict['choices'][0]['message']['content'])['response']
            return search_query
        except Exception as e:
            print(f"Error generating search query: {e}")
            return "Error generating search query"
        
    def get_search_page(self, plan, query, search_results, failed_sites=[], visited_sites=[]):
        payload = {
            "model": self.model,
            "prompt": f"Query: {query}\n\nPlan: {plan} \n\nSearch Results: {search_results}\n\nFailed Sites: {failed_sites}\n\nVisited Sites: {visited_sites}",
            "format": "json",
            "system": get_search_page_prompt,
            "stream": False,
            "temperature": 0
        } if self.server == 'ollama' else {
            "model": self.model,
            "response_format": {"type": "json_object"},
            "messages": [
                {"role": "system", "content": get_search_page_prompt},
                {"role": "user", "content": f"Query: {query}\n\nPlan: {plan}\n\nSearch Results: {search_results}\n\nFailed Sites: {failed_sites}\n\nVisited Sites: {visited_sites}"}
            ],
            "temperature": 0,
            "stop": self.stop
        }
        if self.server == 'openai':
            del payload["stop"]

        try: 
            response = self.session.post(self.model_endpoint, headers=self.headers, json=payload)
            response.raise_for_status()
            response_dict = response.json()
            search_query = json.loads(response_dict['response'])['response'] if self.server == 'ollama' else json.loads(response_dict['choices'][0]['message']['content'])['response']
            return search_query
        except Exception as e:
            print(f"Error getting search page URL: {e}")
            return "Error getting search page URL"
    
    def format_results(self, organic_results):
        return '\n'.join(
            f"Title: {result.get('title', 'No Title')}\nLink: {result.get('link', '#')}\nSnippet: {result.get('snippet', 'No snippet available.')}\n---"
            for result in organic_results
        )
    
    def fetch_search_results(self, search_queries):
        search_url = "https://google.serper.dev/search"
        headers = {
            'Content-Type': 'application/json',
            'X-API-KEY': os.getenv('SERPER_DEV_API_KEY')
        }
        payload = {"q": search_queries}
        
        try:
            response = self.session.post(search_url, headers=headers, json=payload)
            response.raise_for_status()
            results = response.json()
            return self.format_results(results.get('organic', []))
        except requests.exceptions.RequestException as e:
            return f"Request error occurred: {e}"
        
    def scrape_website_content(self, website_url, failed_sites=[]):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Language': 'en-US,en;q=0.9',
            'Referer': 'https://www.google.com/',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Accept-Encoding': 'gzip, deflate, br'
        }

        def is_garbled(text):
            non_ascii_chars = sum(1 for char in text if char not in string.printable)
            return non_ascii_chars / len(text) > 0.2 if text else False
        
        try:
            response = self.session.get(website_url, headers=headers, timeout=15)
            response.raise_for_status()
            detected_encoding = chardet.detect(response.content)
            response.encoding = detected_encoding['encoding'] if detected_encoding['confidence'] > 0.5 else 'utf-8'
            content = response.text
            soup = BeautifulSoup(content, 'html.parser')
            text = soup.get_text(separator='\n')
            clean_text = '\n'.join(line.strip() for line in text.splitlines() if line.strip())
            first_5k_words = ' '.join(clean_text.split()[:5000])

            if is_garbled(clean_text):
                failed_sites.append(website_url)
                return {"source": website_url, "content": "Failed to retrieve content due to garbled text"}, failed_sites, False

            return {"source": website_url, "content": first_5k_words}, "N/A", True
        except requests.exceptions.RequestException as e:
            failed_sites.append(website_url)
            return {"source": website_url, "content": f"Failed to retrieve content due to an error: {e}"}, failed_sites, False
        
    def use_tool(self, plan=None, query=None, visited_sites=[], failed_sites=[]):
        search_queries = self.generate_searches(plan, query)
        search_results = self.fetch_search_results(search_queries)
        best_page = self.get_search_page(plan, query, search_results, visited_sites=visited_sites)
        results_dict, failed_sites, response = self.scrape_website_content(best_page, failed_sites=failed_sites)

        attempts = 0
        while not response and attempts < 5:
            best_page = self.get_search_page(plan, query, search_results, failed_sites=failed_sites)
            results_dict, failed_sites, response = self.scrape_website_content(best_page)
            attempts += 1

        if self.verbose:
            print(f"Search Engine Query: {search_queries}")
            print(colored(f"SEARCH RESULTS {search_results}", 'yellow'))
            print(f"BEST PAGE {best_page}")
            print(f"Scraping URL: {best_page}")
            print(colored(f"RESULTS DICT {results_dict}", 'yellow'))

        return results_dict

if __name__ == '__main__':
    search = WebSearcher(model='your_model_name')
    search.use_tool()
