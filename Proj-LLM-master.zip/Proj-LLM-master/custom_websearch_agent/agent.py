import os
import yaml
import json
import requests
from datetime import datetime, timezone
from termcolor import colored
from prompts import planning_agent_prompt, integration_agent_prompt, check_response_prompt
from search import WebSearcher

def load_config(file_path):
    with open(file_path, 'r') as file:
        config = yaml.safe_load(file)
        for key, value in config.items():
            os.environ[key] = value

def get_current_utc_datetime():
    now_utc = datetime.now(timezone.utc)
    return now_utc.strftime("%Y-%m-%d %H:%M:%S %Z")

def save_feedback(response, json_filename="memory.json"):
    feedback_entry = {"feedback": response}
    data = []

    if os.path.exists(json_filename):
        with open(json_filename, "r") as json_file:
            data = json.load(json_file)
    
    data.append(feedback_entry)

    with open(json_filename, "w") as json_file:
        json.dump(data, json_file, indent=4)

def read_feedback(json_filename="memory.json"):
    if os.path.exists(json_filename):
        with open(json_filename, "r") as json_file:
            data = json.load(json_file)
            return json.dumps(data, indent=4)
    return ""

def clear_json_file(json_filename="memory.json"):
    with open(json_filename, "w") as json_file:
        json.dump([], json_file)

def initialize_json_file(json_filename="memory.json"):
    if not os.path.exists(json_filename) or os.path.getsize(json_filename) == 0:
        with open(json_filename, "w") as json_file:
            json.dump([], json_file)

initialize_json_file()

class Agent:
    def __init__(self, model, model_tool, model_qa, tool, temperature=0, max_tokens=1000, planning_agent_prompt=None, integration_agent_prompt=None, check_response_prompt=None, verbose=False, iterations=5, model_endpoint=None, server=None, stop=None):
        self.server = server
        self.model_endpoint = model_endpoint

        if server == 'openai':
            load_config('config.yaml')
            self.api_key = os.getenv('OPENAI_API_KEY')
            self.headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}'
            }
        else:
            self.headers = {'Content-Type': 'application/json'}
            
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.tool_specs = tool.__doc__
        self.planning_agent_prompt = planning_agent_prompt
        self.integration_agent_prompt = integration_agent_prompt
        self.model = model
        self.tool = tool(model=model_tool, verbose=verbose, model_endpoint=model_endpoint, server=server, stop=stop)
        self.iterations = iterations
        self.model_qa = model_qa
        self.stop = stop
        self.session = requests.Session()

    def make_request(self, payload):
        try:
            response = self.session.post(self.model_endpoint, headers=self.headers, data=json.dumps(payload))
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Request failed: {e}")
            return None

    def run_planning_agent(self, query, plan=None, feedback=None):
        system_prompt = self.planning_agent_prompt.format(
            plan=plan,
            feedback=feedback,
            tool_specs=self.tool_specs,
            datetime=get_current_utc_datetime()
        )
        
        payload = self.create_payload(query, system_prompt)
        response_dict = self.make_request(payload)
        if not response_dict:
            return "Error generating plan"

        return self.extract_response(response_dict, 'Planning Agent')
        
    def run_integration_agent(self, query, plan, outputs, reason, previous_response):
        system_prompt = self.integration_agent_prompt.format(
            outputs=outputs,
            plan=plan,
            reason=reason,
            sources=outputs.get('sources', ''),
            previous_response=previous_response,
            datetime=get_current_utc_datetime(),
            query=query
        )
        
        payload = self.create_payload(query, system_prompt)
        response_dict = self.make_request(payload)
        if not response_dict:
            return "Error generating integration response"
        
        return self.extract_response(response_dict, 'Integration Agent')

    def check_response(self, response, query):
        payload = self.create_payload(
            f"query: {query}\n\nresponse: {response}",
            check_response_prompt,
            model=self.model_qa
        )
        response_dict = self.make_request(payload)
        if not response_dict:
            return "Error in assessing response quality"

        try:
            response_content = response_dict['choices'][0]['message']['content']
            # Replace single quotes with double quotes
            response_content = response_content.replace("'", '"')
            decision_dict = json.loads(response_content)
            print("Response Quality Assessment:", decision_dict)
            return decision_dict
        except json.JSONDecodeError as e:
            print(f"Error decoding JSON response: {e}")
            print(f"Response content: {response_dict}")
            return {"pass": False, "reason": "Invalid JSON response"}

    def create_payload(self, query, system_prompt, model=None):
        model = model or self.model
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": query}
            ],
            "stream": False,
            "temperature": 0,
            "stop": self.stop
        }
        if self.server == 'openai':
            del payload["stop"]
        return payload

    def extract_response(self, response_dict, agent_type):
        if self.server == 'ollama':
            response = response_dict.get('response', '')
        else:
            response = response_dict['choices'][0]['message']['content']
        print(colored(f"{agent_type}: {response}", 'green' if agent_type == 'Planning Agent' else 'cyan'))
        return response

    def execute(self):
        query = input("Enter your query: ")
        meets_requirements = False
        plan, outputs, reason, integration_agent_response = None, None, None, None
        iterations = 0
        visited_sites, failed_sites = [], []
    
        while not meets_requirements and iterations < self.iterations:
            iterations += 1
            feedback = read_feedback("memory.json")
            plan = self.run_planning_agent(query, plan=plan, feedback=feedback)
            outputs = self.tool.use_tool(plan=plan, query=query, visited_sites=visited_sites, failed_sites=failed_sites)
            visited_sites.append(outputs.get('source', ''))

            integration_agent_response = self.run_integration_agent(query=query, plan=plan, outputs=outputs, reason=reason, previous_response=feedback)
            save_feedback(integration_agent_response, "memory.json")
            response_dict = self.check_response(integration_agent_response, query)
            meets_requirements = response_dict.get('pass', '') == 'True'

            if not meets_requirements:
                reason = response_dict.get('reason', '')

        clear_json_file()
        print(colored(f"Final Response: {integration_agent_response}", 'cyan'))

if __name__ == '__main__':
    # Params for OpenAI
    model = 'gpt-4o'
    model_tool = 'gpt-4o'
    model_qa = 'gpt-4o'
    model_endpoint = 'https://api.openai.com/v1/chat/completions'
    stop = None
    server = 'openai'

    # Params for Ollama
    # model = "llama3:latest"
    # model_tool = "llama3:latest"
    # model_qa = "llama3:latest"
    # model_endpoint = 'http://localhost:11434/api/generate'
    # stop = None
    # server = 'ollama'

    # Params for RunPod
    # model = "meta-llama/Meta-Llama-3-70B-Instruct"
    # model_tool = "meta-llama/Meta-Llama-3-70B-Instruct"
    # model_qa = "meta-llama/Meta-Llama-3-70B-Instruct"
    # runpod_endpoint = 'https://hu40e1a0ry7vgl-8000.proxy.runpod.net/'  # Add your RunPod endpoint here
    # completions_endpoint = 'v1/chat/completions'
    # model_endpoint = runpod_endpoint + completions_endpoint
    # stop = "<|eot_id|>"
    # server = 'runpod'

    agent = Agent(
        model=model,
        model_tool=model_tool,
        model_qa=model_qa,
        tool=WebSearcher,
        planning_agent_prompt=planning_agent_prompt,
        integration_agent_prompt=integration_agent_prompt,
        verbose=True,
        iterations=6,
        model_endpoint=model_endpoint,
        server=server
    )
    agent.execute()
